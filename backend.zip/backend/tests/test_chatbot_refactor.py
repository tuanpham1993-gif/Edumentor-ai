"""
Comprehensive tests for EduMentor AI Chatbot Refactor:
Query Router, Search Handler, Knowledge Handler, Code Handler,
Reinforcement Handler, Response Service, and Orchestrator.
Covers all 20 required test scenarios.
"""

import os
import sys
import unittest
from unittest.mock import MagicMock, patch
from uuid import uuid4

# Ensure backend directory is in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.ai.handlers.code_handler import CodeHandler
from app.ai.handlers.knowledge_handler import KnowledgeHandler
from app.ai.handlers.reinforcement_handler import ReinforcementHandler
from app.ai.handlers.search_handler import SearchHandler
from app.ai.orchestrator import ChatOrchestrator
from app.ai.query_router import route_query
from app.ai.response_service import ResponseService


class TestChatbotRefactor(unittest.TestCase):
    """20 Test scenarios covering the complete refactored chatbot architecture."""

    # ==========================================
    # SCENARIOS 1-10: QUERY ROUTER
    # ==========================================

    def test_01_query_router_course_name_search(self):
        """1. Tìm kiếm khóa học theo tên công nghệ / skill."""
        query = "Python có những khóa học nào?"
        result = route_query(query)
        self.assertEqual(result["intent"], "course_search")
        self.assertEqual(result["task_type"], "course_name_search")
        self.assertEqual(result["entity_name"], "Python")
        self.assertIn("sql", result["retrieval_modes"])

    def test_02_query_router_skill_name_search(self):
        """2. Tìm kiếm skill theo tên."""
        query = "Tìm các skill về Machine Learning"
        result = route_query(query)
        self.assertEqual(result["intent"], "skill_search")
        self.assertEqual(result["task_type"], "skill_name_search")
        self.assertEqual(result["entity_name"], "Machine Learning")

    def test_03_query_router_organization_search(self):
        """3. Tìm kiếm khóa học theo tổ chức / trường đại học."""
        query = "Khóa học của University of Alberta"
        result = route_query(query)
        self.assertEqual(result["intent"], "course_search")
        self.assertEqual(result["task_type"], "organization_search")
        self.assertEqual(result["entity_type"], "organization")
        self.assertEqual(result["entity_name"], "University of Alberta")

    def test_04_query_router_rating_search(self):
        """4. Tìm kiếm khóa học theo rating."""
        query = "Cho tôi các khóa học 5 sao"
        result = route_query(query)
        self.assertEqual(result["intent"], "course_search")
        self.assertEqual(result["task_type"], "rating_search")
        self.assertEqual(result["entity_type"], "rating")
        self.assertEqual(result["entity_name"], "5")

    def test_05_query_router_course_semantic_search(self):
        """5. Tìm kiếm ngữ nghĩa khóa học (không có entity cụ thể)."""
        query = "Các khóa học nào tốt nhất"
        result = route_query(query)
        self.assertEqual(result["intent"], "course_search")
        # In course search without specific tech entity, it routes to semantic search or popular
        self.assertIn(result["task_type"], ("course_name_search", "course_semantic_search"))

    def test_06_query_router_skill_semantic_search(self):
        """6. Tìm kiếm ngữ nghĩa kỹ năng."""
        query = "Có kỹ năng nào phổ biến nhất"
        result = route_query(query)
        self.assertEqual(result["intent"], "skill_search")
        self.assertIn(result["task_type"], ("skill_name_search", "skill_semantic_search"))

    def test_07_query_router_code_analysis(self):
        """7. Phân tích code."""
        query = "Giải thích đoạn code sau: def foo(x): return x * 2"
        result = route_query(query)
        self.assertIn(result["intent"], ("code_analysis", "code_help"))
        self.assertEqual(result["task_type"], "code_analysis")

    def test_08_query_router_code_fix(self):
        """8. Sửa lỗi code."""
        query = "Sửa lỗi giúp tôi đoạn code này: def divide(): return 1 / 0"
        result = route_query(query)
        self.assertIn(result["intent"], ("code_fix", "code_help"))
        self.assertEqual(result["task_type"], "code_fix")

    def test_09_query_router_reinforcement_request(self):
        """9. Yêu cầu bài tập, câu hỏi ôn tập củng cố kiến thức."""
        query = "Tạo câu hỏi trắc nghiệm ôn tập về Deep Learning"
        result = route_query(query)
        self.assertIn(result["intent"], ("reinforcement_request", "skill_review"))
        self.assertEqual(result["task_type"], "reinforcement_request")
        self.assertEqual(result["entity_name"], "Deep Learning")

    @patch("app.ai.query_router.query_decomposer.generate_text")
    def test_10_query_router_multi_query(self, mock_llm):
        """10. Phân tách câu hỏi phức hợp (multi-query)."""
        mock_llm.return_value = '{"queries": ["Python là gì?", "Tìm các khóa học về Python"]}'
        query = "Python là gì? Ngoài ra tìm các khóa học về Python giúp tôi"
        result = route_query(query)
        self.assertTrue(result["is_compound"])
        self.assertGreaterEqual(len(result["sub_queries"]), 2)

    # ==========================================
    # SCENARIOS 11-13: SEARCH HANDLER
    # ==========================================

    @patch("app.ai.handlers.search_handler.retrieve_for_query")
    def test_11_search_handler_sql_course(self, mock_retrieve):
        """11. Search Handler truy xuất khóa học qua SQL."""
        mock_retrieve.return_value = {
            "intent": "course_search",
            "found": True,
            "courses": [{"course_id": 1, "title": "Python for Everybody"}],
        }
        handler = SearchHandler()
        mock_db = MagicMock()
        route_res = {
            "intent": "course_search",
            "task_type": "course_name_search",
            "retrieval_modes": ["sql"],
            "entity_name": "Python",
            "entity_type": "skill",
        }
        res = handler.handle(db=mock_db, route_result=route_res, user_content="tìm khóa học python")
        self.assertTrue(res["found"])
        self.assertEqual(len(res["sql_data"]["courses"]), 1)
        mock_retrieve.assert_called_once()

    @patch("app.ai.handlers.search_handler.retrieve_for_query")
    def test_12_search_handler_sql_skill(self, mock_retrieve):
        """12. Search Handler truy xuất skill qua SQL."""
        mock_retrieve.return_value = {
            "intent": "skill_search",
            "found": True,
            "skill": {"skill_id": 10, "skill": "SQL"},
            "related_skills": [{"skill_id": 11, "skill": "PostgreSQL"}],
        }
        handler = SearchHandler()
        mock_db = MagicMock()
        route_res = {
            "intent": "skill_search",
            "task_type": "skill_name_search",
            "retrieval_modes": ["sql"],
            "entity_name": "SQL",
            "entity_type": "skill",
        }
        res = handler.handle(db=mock_db, route_result=route_res, user_content="tìm skill SQL")
        self.assertTrue(res["found"])
        self.assertEqual(res["sql_data"]["skill"]["skill"], "SQL")

    @patch("app.ai.handlers.search_handler.retrieve_knowledge")
    def test_13_search_handler_qdrant_semantic(self, mock_retrieve_rag):
        """13. Search Handler truy xuất tài liệu/ngữ nghĩa qua RAG/Qdrant."""
        mock_retrieve_rag.return_value = [
            {
                "content": "Tài liệu về tính năng Lộ trình học tập",
                "score": 0.88,
                "metadata": {"route": "/ai-learning-path"},
            }
        ]
        handler = SearchHandler()
        mock_db = MagicMock()
        route_res = {
            "intent": "learning_path_request",
            "task_type": "learning_path_request",
            "retrieval_modes": ["rag"],
            "entity_name": None,
            "entity_type": "none",
        }
        res = handler.handle(db=mock_db, route_result=route_res, user_content="làm sao tạo lộ trình")
        self.assertEqual(len(res["rag_data"]), 1)
        self.assertEqual(res["rag_data"][0]["metadata"]["route"], "/ai-learning-path")

    # ==========================================
    # SCENARIOS 14-16: SPECIALIZED HANDLERS
    # ==========================================

    @patch("app.ai.handlers.knowledge_handler.generate_text")
    def test_14_knowledge_handler(self, mock_llm):
        """14. Knowledge Handler gọi Gemini trả lời kiến thức."""
        mock_llm.return_value = '{"answer": "Python là ngôn ngữ lập trình bậc cao.", "suggestions": [{"label": "Học Python", "prompt": "Khóa học Python"}]}'
        handler = KnowledgeHandler()
        route_res = {"intent": "skill_question", "task_type": "knowledge_question"}
        retrieval_ctx = {"sql_data": None, "rag_data": []}
        resp = handler.handle(route_res, retrieval_ctx, "Người dùng: Python là gì?")
        self.assertIn("Python là ngôn ngữ", resp)

    @patch("app.ai.handlers.code_handler.generate_text")
    def test_15_code_handler(self, mock_llm):
        """15. Code Handler gọi Gemini phân tích/sửa lỗi code."""
        mock_llm.return_value = '{"answer": "Lỗi ZeroDivisionError do chia cho 0.", "suggestions": [{"label": "Fix lỗi", "prompt": "Xem code fix"}]}'
        handler = CodeHandler()
        route_res = {"intent": "code_fix", "task_type": "code_fix"}
        resp = handler.handle(route_res, "1 / 0", "Người dùng: lỗi chia cho 0")
        self.assertIn("ZeroDivisionError", resp)

    @patch("app.ai.handlers.reinforcement_handler.generate_text")
    def test_16_reinforcement_handler(self, mock_llm):
        """16. Reinforcement Handler gọi Gemini sinh câu hỏi ôn tập."""
        mock_llm.return_value = '{"answer": "Câu 1: Câu lệnh nào dùng để truy vấn SQL?\\nA. SELECT\\nB. INSERT", "suggestions": [{"label": "Đáp án A", "prompt": "Chọn A"}]}'
        handler = ReinforcementHandler()
        route_res = {"intent": "reinforcement_request", "entity_name": "SQL"}
        resp = handler.handle(route_res, "Tạo câu hỏi SQL", {}, "Người dùng: câu hỏi SQL")
        self.assertIn("Câu 1", resp)

    # ==========================================
    # SCENARIOS 17-19: ORCHESTRATOR
    # ==========================================

    @patch("app.ai.handlers.knowledge_handler.generate_text")
    @patch("app.ai.handlers.search_handler.retrieve_for_query")
    def test_17_orchestrator_full_flow(self, mock_retrieve, mock_llm):
        """17. Toàn bộ luồng Orchestrator cho người dùng đã đăng nhập."""
        mock_retrieve.return_value = {
            "intent": "skill_question",
            "found": True,
            "skill": {"skill_id": 1, "skill": "Python"},
            "courses": [],
        }
        mock_llm.return_value = '{"answer": "Python là ngôn ngữ đa năng.", "suggestions": [{"label": "Khóa học", "prompt": "Tìm khóa học"}]}'

        mock_db = MagicMock()
        mock_db.query().filter().order_by().all.return_value = []
        session_id = uuid4()

        orchestrator = ChatOrchestrator()
        result = orchestrator.process(
            db=mock_db,
            session_id=session_id,
            user_content="Python là gì?",
            allow_sql_retrieval=True,
        )

        self.assertIn("answer", result)
        self.assertIn("suggestions", result)
        self.assertEqual(result["answer"], "Python là ngôn ngữ đa năng.")
        # Assert DB add called twice: once for user message, once for assistant message
        self.assertEqual(mock_db.add.call_count, 2)
        self.assertEqual(mock_db.commit.call_count, 2)

    @patch("app.ai.handlers.knowledge_handler.generate_text")
    @patch("app.ai.query_router.query_decomposer.generate_text")
    def test_18_orchestrator_multi_query_flow(self, mock_decomposer, mock_llm):
        """18. Luồng Orchestrator khi người dùng hỏi multi-query."""
        mock_decomposer.return_value = '{"queries": ["Python là gì?", "Làm sao học Python?"]}'
        mock_llm.return_value = (
            '{"answer": "Python là ngôn ngữ lập trình. Để học, hãy bắt đầu từ cơ bản.", "suggestions": []}'
        )
        mock_db = MagicMock()
        mock_db.query().filter().order_by().all.return_value = []

        orchestrator = ChatOrchestrator()
        result = orchestrator.process(
            db=mock_db,
            session_id=uuid4(),
            user_content="Python là gì? Thêm nữa làm sao để học?",
            allow_sql_retrieval=True,
        )
        self.assertIn("Python là ngôn ngữ lập trình", result["answer"])

    @patch("app.ai.handlers.knowledge_handler.generate_text")
    def test_19_orchestrator_public_chat_flow(self, mock_llm):
        """19. Luồng Orchestrator cho Public Chat (không có session_id, allow_sql=False)."""
        mock_llm.return_value = '{"answer": "Chào mừng bạn đến với EduMentor AI.", "suggestions": []}'
        mock_db = MagicMock()
        orchestrator = ChatOrchestrator()
        result = orchestrator.process(
            db=mock_db,
            session_id=None,
            user_content="Xin chào",
            allow_sql_retrieval=False,
        )

        self.assertIn("answer", result)
        # In public chat, db.add must NEVER be called
        mock_db.add.assert_not_called()

    # ==========================================
    # SCENARIO 20: RESPONSE SERVICE CONTRACT
    # ==========================================

    def test_20_response_service_contract(self):
        """20. Response Service bảo đảm đúng JSON contract cho Frontend."""
        raw_valid = '{"answer": "Chào bạn", "suggestions": [{"label": "Hỏi tiếp", "prompt": "Hỏi thêm"}]}'
        res = ResponseService.format_response(raw_valid)
        self.assertEqual(res["answer"], "Chào bạn")
        self.assertEqual(len(res["suggestions"]), 1)
        self.assertEqual(res["suggestions"][0]["label"], "Hỏi tiếp")

        # Fallback khi LLM trả text thuần
        raw_text = "Đây là văn bản không phải JSON"
        res_fallback = ResponseService.format_response(raw_text)
        self.assertIn("answer", res_fallback)
        self.assertIn("suggestions", res_fallback)
        self.assertIsInstance(res_fallback["suggestions"], list)


if __name__ == "__main__":
    unittest.main()
