"""
Response Service module for EduMentor AI Chatbot.
Normalizes, validates, and packages assistant responses to strictly preserve
the frontend contract: {"answer": str, "suggestions": [{"label": str, "prompt": str}]}.
"""

from typing import Any

from app.ai.validators import parse_ai_response


class ResponseService:
    """
    Standardizes output format from any handler into the required frontend response contract.
    """

    @staticmethod
    def format_response(
        raw_output: str | dict[str, Any],
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """
        Parses raw text or dictionary, validates structure, and applies sanitization.
        """
        if isinstance(raw_output, dict):
            answer = raw_output.get("answer")
            suggestions = raw_output.get("suggestions", [])
            if not isinstance(answer, str) or not answer.strip():
                answer = "Xin lỗi, tôi không thể xử lý câu trả lời lúc này."
            if not isinstance(suggestions, list):
                suggestions = []

            cleaned_suggestions = []
            for item in suggestions[:3]:
                if isinstance(item, dict):
                    label = str(item.get("label", "")).strip()[:40]
                    prompt = str(item.get("prompt", "")).strip()
                    if label and prompt:
                        cleaned_suggestions.append(
                            {
                                "label": label,
                                "prompt": prompt,
                            }
                        )

            result = {
                "answer": answer,
                "suggestions": cleaned_suggestions,
            }
        elif isinstance(raw_output, str):
            try:
                result = parse_ai_response(raw_output)
            except Exception:
                result = {
                    "answer": raw_output.strip(),
                    "suggestions": [],
                }
        else:
            result = {
                "answer": "Đã xảy ra lỗi khi tạo phản hồi.",
                "suggestions": [],
            }

        if metadata:
            result["metadata"] = metadata

        return result


response_service = ResponseService()
