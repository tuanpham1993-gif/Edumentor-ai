"""
Query decomposer module for Query Router.
Detects and splits compound queries into sub-queries.
"""

from app.ai.client import generate_text
from app.ai.query_router.normalizer import extract_json_object, normalize_text


def may_contain_multiple_requests(user_message: str) -> bool:
    """
    Kiểm tra sơ bộ xem tin nhắn có khả năng chứa
    nhiều yêu cầu độc lập hay không.
    """
    text = normalize_text(user_message)

    connectors = [
        " ngoai ra ",
        " ben canh do ",
        " dong thoi ",
        " them nua ",
        " them cho toi ",
        " sau do ",
        " tiep theo ",
        " khong nhung ",
        " ma con ",
        " cung nhu ",
        ";",
        "\n",
    ]

    has_multiple_questions = user_message.count("?") > 1
    return any(connector in text for connector in connectors) or has_multiple_questions


def decompose_query_by_llm(user_message: str) -> list[str]:
    """
    Dùng Gemini tách một tin nhắn thành các yêu cầu độc lập.
    Hàm này chỉ tách yêu cầu, không phân loại intent.
    """
    prompt = f"""
Bạn là Query Decomposer của EduMentor AI.

NHIỆM VỤ:
Phân tích tin nhắn người dùng và tách thành các yêu cầu
độc lập có thể cần xử lý riêng.

QUY TẮC:
1. Một tin nhắn có thể có một hoặc nhiều yêu cầu.
2. Không giới hạn số lượng yêu cầu.
3. Không phụ thuộc vào dấu chấm, dấu phẩy hoặc dấu hỏi.
4. Hiểu các từ nối tiếng Việt như: ngoài ra, bên cạnh đó, thêm nữa, và, đồng thời, sau đó.
5. Chỉ tách khi người dùng thực sự đưa ra một yêu cầu có thể xử lý độc lập.
6. Giữ nguyên ngữ cảnh và chủ đề chung.
7. Không tự thêm yêu cầu người dùng không nói.
8. Giữ nguyên tên công nghệ, Skill, Course.
9. Nếu chỉ có một yêu cầu, trả về một phần tử.
10. Chỉ trả về JSON hợp lệ:

{{
    "queries": [
        "Yêu cầu thứ nhất",
        "Yêu cầu thứ hai"
    ]
}}

TIN NHẮN NGƯỜI DÙNG:
{user_message}
"""
    ai_text = generate_text(prompt)
    result = extract_json_object(ai_text)
    queries = result.get("queries")

    if not isinstance(queries, list):
        raise ValueError("LLM không trả về danh sách queries.")

    cleaned_queries = []
    for query in queries:
        if not isinstance(query, str):
            continue
        query = query.strip()
        if query and query not in cleaned_queries:
            cleaned_queries.append(query)

    if not cleaned_queries:
        raise ValueError("Không tách được yêu cầu từ câu hỏi.")

    return cleaned_queries
