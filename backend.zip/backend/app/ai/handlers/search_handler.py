"""
Search Handler module for EduMentor AI.
Coordinates SQL retrieval (PostgreSQL), Qdrant semantic search, and RAG knowledge retrieval.
"""

from typing import Any

from sqlalchemy.orm import Session

from app.ai.query_router.config import (
    INTENT_CATEGORY_MAP,
    ROUTE_CATEGORY_MAP,
    ROUTE_KEYWORDS,
)
from app.ai.query_router.normalizer import normalize_text
from app.services.rag_service import retrieve_knowledge
from app.services.sql_retrieval import retrieve_for_query

RAG_TOP_K = 12


class SearchHandler:
    """
    Search Handler coordinates retrieval across PostgreSQL (exact/relational)
    and Qdrant / RAG (semantic / documentation).
    """

    def detect_target_route(self, text: str) -> str | None:
        """Phát hiện route frontend từ từ khóa trong câu hỏi."""
        normalized = normalize_text(text)
        for route, keywords in ROUTE_KEYWORDS.items():
            for kw in keywords:
                if kw in normalized:
                    return route
        return None

    def build_expanded_rag_query(
        self,
        user_content: str,
        route_result: dict,
    ) -> tuple[str, str | None, str | None]:
        """Tạo expanded query để tăng độ chính xác của RAG."""
        intent = route_result.get("intent")
        entity_name = route_result.get("entity_name")
        target_route = self.detect_target_route(user_content)
        target_category = None

        if target_route and target_route in ROUTE_CATEGORY_MAP:
            target_category = ROUTE_CATEGORY_MAP[target_route]
        elif intent in INTENT_CATEGORY_MAP:
            target_category = INTENT_CATEGORY_MAP[intent]

        expanded_parts = [user_content]
        if target_route:
            expanded_parts.append(f"Route: {target_route}")
        if target_category:
            expanded_parts.append(f"Category: {target_category}")
        if entity_name:
            expanded_parts.append(f"Entity: {entity_name}")

        expanded_query = " | ".join(expanded_parts)
        return expanded_query, target_route, target_category

    def build_retrieval_context(
        self,
        db: Session,
        route_result: dict,
        user_content: str,
        allow_sql: bool = True,
    ) -> dict[str, Any]:
        """
        Xây dựng ngữ cảnh truy xuất đầy đủ gồm SQL data và RAG data.
        """
        retrieval_modes = route_result.get("retrieval_modes", [])

        context: dict[str, Any] = {
            "intent": route_result.get("intent"),
            "task_type": route_result.get("task_type"),
            "retrieval_strategy": route_result.get("retrieval_strategy"),
            "entity_type": route_result.get("entity_type"),
            "entity_name": route_result.get("entity_name"),
            "routing_source": route_result.get("source"),
            "target_route": None,
            "target_category": None,
            "expanded_query": user_content,
            "sql_data": None,
            "rag_data": [],
        }

        # 1. SQL Retrieval
        if "sql" in retrieval_modes and allow_sql:
            try:
                sql_result = retrieve_for_query(
                    db=db,
                    route_result=route_result,
                )
                context["sql_data"] = sql_result
            except Exception as e:
                print(f"[SEARCH HANDLER] SQL retrieval error: {e}")
                context["sql_data"] = {"found": False, "error": str(e)}

        # 2. RAG Retrieval
        if "rag" in retrieval_modes:
            try:
                expanded_query, target_route, target_category = self.build_expanded_rag_query(
                    user_content=user_content,
                    route_result=route_result,
                )
                context["expanded_query"] = expanded_query
                context["target_route"] = target_route
                context["target_category"] = target_category

                rag_results = retrieve_knowledge(
                    query=expanded_query,
                    top_k=RAG_TOP_K,
                )
                context["rag_data"] = rag_results
            except Exception as e:
                print(f"[SEARCH HANDLER] RAG retrieval error: {e}")
                context["rag_data"] = []

        return context

    def handle(
        self,
        db: Session,
        route_result: dict,
        user_content: str,
        allow_sql: bool = True,
    ) -> dict[str, Any]:
        """
        Thực thi tìm kiếm và đóng gói kết quả tìm kiếm.
        """
        context = self.build_retrieval_context(
            db=db,
            route_result=route_result,
            user_content=user_content,
            allow_sql=allow_sql,
        )

        sql_data = context.get("sql_data") or {}
        found = bool(sql_data.get("found", False) if isinstance(sql_data, dict) else False)

        return {
            "search_type": route_result.get("task_type", "search"),
            "retrieval_context": context,
            "sql_data": sql_data,
            "rag_data": context.get("rag_data", []),
            "found": found,
        }


search_handler = SearchHandler()
