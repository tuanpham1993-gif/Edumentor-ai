"""
Orchestrator module for EduMentor AI Chatbot.
Coordinates Query Routing, Search, Knowledge, Code, Reinforcement Handlers,
and Response Service with session state and history persistence.
"""

import json
from typing import Any
from uuid import UUID

from sqlalchemy.orm import Session

from app.ai.handlers.code_handler import code_handler
from app.ai.handlers.knowledge_handler import knowledge_handler
from app.ai.handlers.reinforcement_handler import reinforcement_handler
from app.ai.handlers.search_handler import search_handler
from app.ai.query_router import route_query
from app.ai.response_service import response_service
from app.models.chat_message import ChatMessage


def format_assistant_history(saved_response: dict) -> str:
    """Chuyển phản hồi assistant đã lưu thành văn bản cho history."""
    answer = saved_response.get("answer", "")
    if isinstance(answer, str):
        return answer
    if isinstance(answer, dict):
        history_parts = []
        for field in (
            "concept",
            "real_world_example",
            "code_example",
            "code_explanation",
            "practical_application",
        ):
            value = answer.get(field, "")
            if isinstance(value, str) and value.strip():
                history_parts.append(value.strip())
        return "\n".join(history_parts)
    return str(answer)


class ChatOrchestrator:
    """
    Central coordinator of the EduMentor AI Chatbot.
    Orchestrates:
    User Input -> Query Router -> Handlers (Search, Knowledge, Code, Reinforcement)
    -> Response Service -> Persistence -> Client.
    """

    def __init__(self):
        self.search_handler = search_handler
        self.knowledge_handler = knowledge_handler
        self.code_handler = code_handler
        self.reinforcement_handler = reinforcement_handler
        self.response_service = response_service

    def process(
        self,
        db: Session,
        session_id: UUID | None,
        user_content: str,
        allow_sql_retrieval: bool = True,
        custom_api_key: str | None = None,
    ) -> dict[str, Any]:
        """
        Xử lý toàn bộ luồng hội thoại của Chatbot.
        """
        if not isinstance(user_content, str) or not user_content.strip():
            raise ValueError("Message cannot be empty.")

        user_content = user_content.strip()

        # ======================================
        # STEP 1. SAVE USER MESSAGE
        # ======================================
        if session_id is not None:
            user_msg_record = ChatMessage(
                session_id=session_id,
                role="user",
                content=user_content,
            )
            db.add(user_msg_record)
            db.commit()
        else:
            print("\n========== PUBLIC CHAT ==========")
            print("Không lưu user message vào database.")

        # ======================================
        # STEP 2. GET CONVERSATION HISTORY
        # ======================================
        history: list[ChatMessage] = []
        if session_id is not None:
            history = (
                db.query(ChatMessage)
                .filter(ChatMessage.session_id == session_id)
                .order_by(
                    ChatMessage.created_at.asc(),
                    ChatMessage.message_id.asc(),
                )
                .all()
            )

            conversation_lines = []
            for message in history:
                content = message.content
                if message.role == "assistant":
                    try:
                        saved_resp = json.loads(content)
                        if isinstance(saved_resp, dict):
                            content = format_assistant_history(saved_resp)
                    except (json.JSONDecodeError, TypeError):
                        pass

                role_name = "Người dùng" if message.role == "user" else "Gia sư AI"
                conversation_lines.append(f"{role_name}: {content}")
            conversation = "\n".join(conversation_lines)
        else:
            conversation = f"Người dùng: {user_content}"

        # ======================================
        # STEP 3. QUERY ROUTER
        # ======================================
        route_result = route_query(user_content)

        # Context inheritance (anaphoric references)
        if route_result.get("entity_name") is None and history:
            for prev_message in reversed(history):
                if prev_message.role == "user" and prev_message.content:
                    try:
                        prev_route = route_query(prev_message.content)
                        if prev_route.get("entity_name"):
                            route_result["entity_name"] = prev_route["entity_name"]
                            if route_result.get("entity_type") in ("none", None):
                                route_result["entity_type"] = prev_route.get("entity_type", "skill")
                            route_result["source"] = "conversation_context"
                            if route_result.get("sub_queries"):
                                route_result["sub_queries"][0]["entity_name"] = route_result["entity_name"]
                                route_result["sub_queries"][0]["entity_type"] = route_result["entity_type"]
                                route_result["sub_queries"][0]["source"] = "conversation_context"
                            break
                    except Exception:
                        pass

        print("\n========== QUERY ROUTER ==========")
        print(json.dumps(route_result, ensure_ascii=False, indent=2))

        # ======================================
        # STEP 4. RETRIEVE CONTEXT VIA SEARCH HANDLER
        # ======================================
        search_res = self.search_handler.handle(
            db=db,
            route_result=route_result,
            user_content=user_content,
            allow_sql=allow_sql_retrieval,
        )
        retrieval_context = search_res["retrieval_context"]

        print("\n========== RETRIEVAL CONTEXT ==========")
        print(json.dumps(retrieval_context, ensure_ascii=False, indent=2, default=str))

        # ======================================
        # STEP 5. HANDLER SELECTION & EXECUTION
        # ======================================
        task_type = route_result.get("task_type", "knowledge_question")
        intent = route_result.get("intent", "general_question")

        # 5.1 Code Handler
        if task_type in ("code_analysis", "code_fix") or intent in ("code_help", "code_analysis", "code_fix"):
            print("\n========== ROUTED TO CODE HANDLER ==========")
            raw_response = self.code_handler.handle(
                route_result=route_result,
                user_content=user_content,
                conversation_history=conversation,
                custom_api_key=custom_api_key,
            )

        # 5.2 Reinforcement Handler
        elif task_type in ("reinforcement_request", "skill_review") or intent in (
            "reinforcement_request",
            "skill_review",
        ):
            print("\n========== ROUTED TO REINFORCEMENT HANDLER ==========")
            raw_response = self.reinforcement_handler.handle(
                route_result=route_result,
                user_content=user_content,
                retrieval_context=retrieval_context,
                conversation_history=conversation,
                custom_api_key=custom_api_key,
            )

        # 5.3 Knowledge / Search / System Operation Handler
        else:
            print("\n========== ROUTED TO KNOWLEDGE HANDLER ==========")
            raw_response = self.knowledge_handler.handle(
                route_result=route_result,
                retrieval_context=retrieval_context,
                conversation_history=conversation,
                custom_api_key=custom_api_key,
            )

        # ======================================
        # STEP 6. RESPONSE SERVICE VALIDATION
        # ======================================
        response_data = self.response_service.format_response(
            raw_output=raw_response,
            metadata={
                "intent": intent,
                "task_type": task_type,
                "source": route_result.get("source"),
            },
        )

        # ======================================
        # STEP 7. PERSIST ASSISTANT RESPONSE
        # ======================================
        if session_id is not None:
            # We save the clean JSON containing answer and suggestions (contract)
            db_save_data = {
                "answer": response_data["answer"],
                "suggestions": response_data["suggestions"],
            }
            ai_message = ChatMessage(
                session_id=session_id,
                role="assistant",
                content=json.dumps(db_save_data, ensure_ascii=False),
            )
            db.add(ai_message)
            db.commit()
            db.refresh(ai_message)

        return response_data


orchestrator = ChatOrchestrator()
