
from sentence_transformers import SentenceTransformer


# ==========================================
# 1. EMBEDDING MODEL CONFIGURATION
# ==========================================

EMBEDDING_MODEL_NAME = (
    "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"
)

EMBEDDING_DIMENSION = 384


# ==========================================
# 2. INITIALIZE EMBEDDING MODEL
# ==========================================

embedding_model_tutor = SentenceTransformer(
    EMBEDDING_MODEL_NAME
)

embedding_model_tutor.max_seq_length = 128
