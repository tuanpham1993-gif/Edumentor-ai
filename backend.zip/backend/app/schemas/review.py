"""Schema API ôn tập (module 09 · Tuấn · GĐ2, 09/11/2026).

Nguyên tắc bảo mật: đề trả về cho người làm (AttemptOut) KHÔNG có correct_index, rubric, explanation
— chỉ trả sau khi nộp (GĐ3, lịch sử bài làm).
"""

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field, field_validator

QuestionType = Literal["mcq", "essay"]
QuestionLevel = Literal["recognize", "understand", "easy", "advanced"]
AttemptStatus = Literal["in_progress", "grading", "graded"]

MAX_ESSAY_CHARS = 5000


class ReviewSkillOut(BaseModel):
    skill_id: int
    skill: str


class ReviewStructureOut(BaseModel):
    """Cấu trúc đề (chốt 09/11) — hiển thị ở màn Bắt đầu ôn tập."""

    recognize: int
    understand: int
    easy: int
    advanced: int
    total_questions: int
    max_score: float


class ReviewBlockedOut(BaseModel):
    """Lý do chưa thể ôn tập. code: not_enrolled | abandoned | no_question_bank | too_many_unfinished."""

    code: str
    message: str


class AttemptSummaryOut(BaseModel):
    attempt_id: int
    status: AttemptStatus
    score: float | None
    passed: bool | None
    started_at: datetime
    submitted_at: datetime | None


class UnfinishedAttemptOut(BaseModel):
    """Bài làm dở ở khóa khác (19/11) — hiện khi đủ số bài dở tối đa để người học Tiếp tục / Bỏ bớt."""

    attempt_id: int
    course_id: int
    course_title: str
    answered: int
    total: int
    started_at: datetime


class ReviewInfoOut(BaseModel):
    course_id: int
    course_title: str
    skills: list[ReviewSkillOut]
    structure: ReviewStructureOut
    pass_score: float
    can_start: bool
    blocked: ReviewBlockedOut | None
    in_progress_attempt_id: int | None
    unfinished_attempts: list[UnfinishedAttemptOut] = []
    attempts: list[AttemptSummaryOut]


class AttemptQuestionOut(BaseModel):
    position: int
    type: QuestionType
    level: QuestionLevel
    skill_id: int
    skill: str
    content: str
    options: list[str] | None  # đã XÁO theo option_order; None với tự luận
    max_points: float
    selected_index: int | None  # vị trí người dùng chọn TRÊN MÀN HÌNH (0..3)
    text_answer: str | None


class AttemptOut(BaseModel):
    attempt_id: int
    course_id: int
    course_title: str
    status: AttemptStatus
    started_at: datetime
    resumed: bool = False  # True = trả lại lượt đang làm dở thay vì tạo đề mới
    answered: int
    total_questions: int
    questions: list[AttemptQuestionOut]


class AnswerIn(BaseModel):
    """Một câu trả lời. TN gửi selected_index (null = bỏ chọn); TL gửi text_answer."""

    position: int = Field(ge=1)
    selected_index: int | None = Field(default=None, ge=0, le=3)
    text_answer: str | None = Field(default=None, max_length=MAX_ESSAY_CHARS)


class SaveAnswersRequest(BaseModel):
    answers: list[AnswerIn] = Field(min_length=1, max_length=50)

    @field_validator("answers")
    @classmethod
    def unique_positions(cls, answers: list[AnswerIn]) -> list[AnswerIn]:
        positions = [a.position for a in answers]
        if len(set(positions)) != len(positions):
            raise ValueError("Mỗi câu (position) chỉ được gửi một lần")
        return answers


# ─────────────── Kết quả, lịch sử (GĐ3) ───────────────


class RubricResultOut(BaseModel):
    text: str
    max_points: float
    result: Literal["full", "partial", "none"]  # partial: chỉ còn ở bài chấm trước 15/11 (lịch sử)
    points: float
    evidence: str | None  # câu trích từ bài làm làm bằng chứng
    reason: str | None = None  # B11: lý do AI chấm ý này (B7); None khi chấm từ khóa / bài chấm trước 15/11


class ResultQuestionOut(BaseModel):
    position: int
    type: QuestionType
    level: QuestionLevel
    skill_id: int
    skill: str
    content: str
    max_points: float
    points: float
    explanation: str | None  # giải thích (TN) / đáp án mẫu (TL)
    options: list[str] | None
    selected_index: int | None
    correct_index: int | None  # vị trí đáp án đúng TRÊN MÀN HÌNH
    is_correct: bool | None
    text_answer: str | None
    rubric: list[RubricResultOut] | None
    # B11 (16/11) — chỉ câu tự luận có bài làm; None / False với trắc nghiệm, bài bỏ trống, lượt chấm trước B6
    graded_by: Literal["ai", "keyword"] | None = None  # keyword: AI_MODE=mock hoặc Gemini lỗi → chấm từ khóa dự phòng
    needs_review: bool = False  # D8/D10: điểm AI và từ khóa vẫn lệch sau khi chấm lại → điểm tính tạm, đang xem lại
    reviewed: bool = False  # 17/11: giáo viên đã xem lại / chấm lại câu này (trang admin "Bài cần xem lại")
    feedback: str | None = None  # nhận xét chung của AI (B7)


class AttemptResultOut(BaseModel):
    attempt_id: int
    course_id: int
    course_title: str
    status: AttemptStatus
    score: float | None
    passed: bool | None
    pass_score: float
    mcq_score: float | None  # None khi status="grading" (đang chấm — T1)
    essay_score: float | None
    completed_course: bool  # lượt này làm khóa Hoàn thành + kỹ năng "Đã biết" (đạt lần đầu — B1)
    started_at: datetime
    submitted_at: datetime | None
    questions: list[ResultQuestionOut]


class HistoryItemOut(AttemptSummaryOut):
    course_id: int
    course_title: str
    completed_course: bool


class SkillReviewCourseOut(BaseModel):
    """Một khóa ôn tập được cho kỹ năng (20/11 — huy hiệu ôn tập trên đồ thị lộ trình)."""

    course_id: int
    course_title: str
    enrollment: Literal["ongoing", "completed"]
    in_progress_attempt_id: int | None
    last_attempt: AttemptSummaryOut | None  # lần nộp gần nhất (đã chấm / đang chấm); None = chưa ôn


class SkillReviewOut(BaseModel):
    skill_id: int
    courses: list[SkillReviewCourseOut]  # rỗng = kỹ năng chưa có khóa nào để ôn → không hiện huy hiệu


class SkillReviewsOut(BaseModel):
    items: list[SkillReviewOut]  # đúng thứ tự skill_ids gửi lên (bỏ trùng)


class HistoryPage(BaseModel):
    items: list[HistoryItemOut]
    total: int
    page: int
    size: int


class AttemptTraceOut(BaseModel):
    attempt_id: int
    user_id: int
    course_id: int
    status: AttemptStatus
    score: float | None
    started_at: datetime
    submitted_at: datetime | None
    trace: dict
