"""
RAG Service (LlamaIndex disabled per project architecture).
Provides retrieve_knowledge interface returning empty list or fallback results.
"""

DEFAULT_TOP_K = 5


def retrieve_knowledge(
    query: str,
    top_k: int = DEFAULT_TOP_K,
) -> list[dict]:
    """
    RAG retrieval stub. Returns empty list as LlamaIndex is deprecated
    in favor of direct Qdrant services and Gemini.
    """
    if not isinstance(query, str) or not query.strip():
        raise ValueError("Query cannot be empty.")

    if not isinstance(top_k, int) or isinstance(top_k, bool) or top_k < 1:
        raise ValueError("top_k must be a positive integer.")

    return []
